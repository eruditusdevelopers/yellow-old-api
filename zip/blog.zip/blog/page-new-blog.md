---
Title: Blog page
Published: @datetime
Author: @username
Template: blog
Tag: Example
---
This is a new blog page.