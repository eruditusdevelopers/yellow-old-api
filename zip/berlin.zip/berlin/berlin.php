<?php
// Berlin theme, https://github.com/datenstrom/yellow-themes/tree/master/berlin
// Copyright (c) 2013-2018 Datenstrom, https://datenstrom.se
// This file may be used and distributed under the terms of the public license.

class YellowThemeBerlin
{
	const VERSION = "0.7.6";	
}

$yellow->themes->register("berlin", "YellowThemeBerlin", YellowThemeBerlin::VERSION);
?>
