<?php
// Paris theme, https://github.com/datenstrom/yellow-themes/tree/master/paris
// Copyright (c) 2013-2018 Datenstrom, https://datenstrom.se
// This file may be used and distributed under the terms of the public license.

class YellowThemeParis {
    const VERSION = "0.7.6";
}

$yellow->themes->register("paris", "YellowThemeParis", YellowThemeParis::VERSION);
